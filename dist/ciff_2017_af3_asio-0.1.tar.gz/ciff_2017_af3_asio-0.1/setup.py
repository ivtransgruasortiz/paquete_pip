from distutils.core import setup
setup(
  name = 'ciff_2017_af3_asio',
  packages = ['ciff_2017_af3_asio'], # this must be the same as the name above
  version = '0.1',
  description = 'oportunidad de subida Andres Salamanca e Ivan Ortiz',
  author = 'Andres Salamanca e Ivan Ortiz',
  author_email = 'ivanortiz@campusciff.net',
  url = 'https://github.com/ivtransgruasortiz/paquete_pip/', # use the URL to the github repo
  download_url = 'https://github.com/ivtransgruasortiz/paquete_pip/tarball/0.1',
  keywords = ['paquete', 'oportunidaddesubida'],
  classifiers = [],
)
